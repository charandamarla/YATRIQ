require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const frontendOrigin = process.env.FRONTEND_ORIGIN;
const databaseFile = path.resolve(__dirname, process.env.DATABASE_FILE || './data/yatriq.sqlite');

fs.mkdirSync(path.dirname(databaseFile), { recursive: true });
const db = new Database(databaseFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    page TEXT NOT NULL CHECK(page IN ('home','national','international','multi')),
    name TEXT NOT NULL,
    rating INTEGER NOT NULL CHECK(rating BETWEEN 3 AND 5),
    review TEXT NOT NULL,
    approved INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS contact_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    topic TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS demo_bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_ref TEXT NOT NULL UNIQUE,
    trip_type TEXT NOT NULL CHECK(trip_type IN ('national','international','multi')),
    destination TEXT NOT NULL,
    start_date TEXT,
    end_date TEXT,
    travellers INTEGER NOT NULL CHECK(travellers BETWEEN 1 AND 30),
    budget_inr INTEGER NOT NULL CHECK(budget_inr >= 5000),
    status TEXT NOT NULL DEFAULT 'DEMO_ONLY',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
if (frontendOrigin) {
  app.use(cors({ origin: frontendOrigin.split(',').map(x => x.trim()), methods: ['GET','POST'], allowedHeaders: ['Content-Type'] }));
}
app.use(express.json({ limit: '30kb' }));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: 'draft-8', legacyHeaders: false }));

const clean = (value, max = 500) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const validPage = value => ['home','national','international','multi'].includes(value);

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'YATRIQ API', database: 'connected', mode: 'student-demo' });
});

app.get('/api/reviews', (req, res) => {
  const page = clean(req.query.page, 20) || 'home';
  if (!validPage(page)) return res.status(400).json({ error: 'Invalid review page.' });
  const rows = db.prepare(`
    SELECT id, page, name, rating, review AS text, created_at AS createdAt
    FROM reviews WHERE page = ? AND approved = 1 ORDER BY created_at DESC LIMIT 100
  `).all(page);
  res.json({ reviews: rows });
});

app.post('/api/reviews', (req, res) => {
  const page = clean(req.body?.page, 20);
  const name = clean(req.body?.name, 60);
  const review = clean(req.body?.review, 1000);
  const rating = Number(req.body?.rating);
  if (!validPage(page)) return res.status(400).json({ error: 'Choose a valid review section.' });
  if (name.length < 2) return res.status(400).json({ error: 'Name must contain at least 2 characters.' });
  if (![3,4,5].includes(rating)) return res.status(400).json({ error: 'Rating must be 3, 4 or 5 stars.' });
  if (review.length < 20) return res.status(400).json({ error: 'Review must contain at least 20 characters.' });
  const result = db.prepare('INSERT INTO reviews (page, name, rating, review) VALUES (?, ?, ?, ?)').run(page, name, rating, review);
  res.status(201).json({ message: 'Review submitted for moderation.', id: Number(result.lastInsertRowid), approved: false });
});

app.post('/api/contact', (req, res) => {
  const name = clean(req.body?.name, 60);
  const email = clean(req.body?.email, 254);
  const topic = clean(req.body?.topic, 80) || 'General enquiry';
  const message = clean(req.body?.message, 2000);
  if (name.length < 2) return res.status(400).json({ error: 'Please enter your name.' });
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  if (message.length < 10) return res.status(400).json({ error: 'Message must contain at least 10 characters.' });
  const result = db.prepare('INSERT INTO contact_messages (name, email, topic, message) VALUES (?, ?, ?, ?)').run(name, email || null, topic, message);
  res.status(201).json({ message: 'Message received.', id: Number(result.lastInsertRowid) });
});

app.post('/api/bookings/demo', (req, res) => {
  const tripType = clean(req.body?.tripType, 20);
  const destination = clean(req.body?.destination, 160);
  const startDate = clean(req.body?.startDate, 10) || null;
  const endDate = clean(req.body?.endDate, 10) || null;
  const travellers = Number(req.body?.travellers);
  const budget = Number(req.body?.budgetInr);
  if (!['national','international','multi'].includes(tripType)) return res.status(400).json({ error: 'Invalid trip type.' });
  if (destination.length < 2) return res.status(400).json({ error: 'Please provide a destination.' });
  if (!Number.isInteger(travellers) || travellers < 1 || travellers > 30) return res.status(400).json({ error: 'Travellers must be between 1 and 30.' });
  if (!Number.isInteger(budget) || budget < 5000 || budget > 100000000) return res.status(400).json({ error: 'Budget must be between ₹5,000 and ₹10 crore.' });
  if (startDate && !/^\d{4}-\d{2}-\d{2}$/.test(startDate)) return res.status(400).json({ error: 'Start date must use YYYY-MM-DD.' });
  if (endDate && !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) return res.status(400).json({ error: 'End date must use YYYY-MM-DD.' });
  const bookingRef = 'YQ-DEMO-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  db.prepare(`INSERT INTO demo_bookings (booking_ref, trip_type, destination, start_date, end_date, travellers, budget_inr)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run(bookingRef, tripType, destination, startDate, endDate, travellers, budget);
  res.status(201).json({
    bookingRef,
    status: 'DEMO_ONLY',
    message: 'Demo reference created. No hotel, transport, or payment has been booked.',
    paymentProcessed: false
  });
});

// Serve the existing static website from the parent project folder.
const websiteDir = path.resolve(__dirname, '..');
app.use('/server', (req, res) => res.status(404).json({ error: 'Not found.' }));
app.use(express.static(websiteDir, { dotfiles: 'ignore', index: 'index.html' }));
app.get('/', (req, res) => res.sendFile(path.join(websiteDir, 'index.html')));

app.use((req, res) => res.status(404).json({ error: 'Route not found.' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Unexpected server error.' });
});

app.listen(PORT, () => {
  console.log(`YATRIQ website + API: http://localhost:${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
});
