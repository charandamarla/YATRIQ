# YATRIQ Backend (Node.js + Express + SQLite)

This backend runs alongside the existing YATRIQ HTML/CSS/JavaScript website. It adds persistent server-side storage for submitted reviews, contact messages, and **demo-only** booking references.

## Requirements
- Node.js 20 or newer
- npm (included with Node.js)

## Start it on Windows
1. Extract the project ZIP.
2. Open the `yatriq-multicity` folder in VS Code.
3. Open Terminal in VS Code.
4. Run:

   ```bash
   cd server
   npm install
   copy .env.example .env
   npm start
   ```

5. Open `http://localhost:3000` (not by double-clicking `index.html`).
6. Test `http://localhost:3000/api/health`. It should return JSON with `"ok": true`.

On macOS/Linux, use `cp .env.example .env` instead of `copy`.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Check server/database |
| GET | `/api/reviews?page=home` | Get approved reviews for `home`, `national`, `international`, or `multi` |
| POST | `/api/reviews` | Submit a review for moderation |
| POST | `/api/contact` | Save a contact message |
| POST | `/api/bookings/demo` | Create a demo booking reference only |

### Example review request
```json
{
  "page": "national",
  "name": "Demo Student",
  "rating": 5,
  "review": "The itinerary was easy to understand and the hotel suggestions were useful."
}
```

New reviews are stored as pending (`approved = 0`), so they will not appear publicly until approved. This is intentional moderation. For a local classroom demo, you can inspect the SQLite database using a SQLite viewer. To approve a review, run an SQL update against the `reviews` table, for example:

```sql
UPDATE reviews SET approved = 1 WHERE id = 1;
```

### Example demo booking request
```json
{
  "tripType": "national",
  "destination": "Vijayawada to Jaipur",
  "startDate": "2026-11-10",
  "endDate": "2026-11-14",
  "travellers": 2,
  "budgetInr": 25000
}
```

The booking endpoint only saves a demo reference. It does **not** charge money or book flights, trains, buses, or hotels.

## Frontend notes
The current site was originally designed as a static prototype. This backend exposes APIs, but existing front-end forms must call those endpoints to use server-side storage. Existing review submissions may still use browser local storage until `reviews.js` is connected to the API.

## Security and production limitations
- Do not collect or store real Aadhaar, passport, visa, card, UPI PIN, or other payment credentials in this demo.
- Do not treat the QR image as proof of payment. No payment gateway is connected.
- Contact messages may contain personal data. Add access controls, retention rules, consent and a privacy notice before public deployment.
- Reviews are pending moderation by default. Do not publish unverified sample reviews as real testimonials.
- Before production, add authentication and an admin-only moderation interface, HTTPS, backups, logging, deployment configuration, and a real provider integration only if needed.
- The database file is created at `server/data/yatriq.sqlite` the first time the server starts and should not be committed to Git.
